--!native
--!nocheck
-- Doom en Roblox: cliente completo. Hijos esperados: DoomWasm (ModuleScript) y WadChunks (Folder).
local AssetService = game:GetService("AssetService")
local RunService = game:GetService("RunService")
local UIS = game:GetService("UserInputService")
local Players = game:GetService("Players")

local W, H = 320, 200
local WAD_NAME = "doom1.wad"

-- ============ UI ============
local gui = Instance.new("ScreenGui")
gui.IgnoreGuiInset = true
gui.ResetOnSpawn = false
gui.Parent = Players.LocalPlayer:WaitForChild("PlayerGui")
local bg = Instance.new("Frame")
bg.Size = UDim2.fromScale(1, 1)
bg.BackgroundColor3 = Color3.new(0, 0, 0)
bg.Parent = gui
local label = Instance.new("ImageLabel")
label.AnchorPoint = Vector2.new(0.5, 0.5)
label.Position = UDim2.fromScale(0.5, 0.5)
label.Size = UDim2.fromScale(1, 1)
label.BackgroundTransparency = 1
label.ResampleMode = Enum.ResamplerMode.Pixelated
label.Parent = bg
local ratio = Instance.new("UIAspectRatioConstraint")
ratio.AspectRatio = 4 / 3
ratio.Parent = label
local status = Instance.new("TextLabel")
status.Size = UDim2.fromScale(1, 0.1)
status.BackgroundTransparency = 1
status.TextColor3 = Color3.new(1, 1, 1)
status.TextScaled = true
status.Text = "Cargando WAD..."
status.Parent = bg

-- ============ Utilidades ============
local lastYield = os.clock()
local function maybeYield()
	if os.clock() - lastYield > 0.008 then
		task.wait()
		lastYield = os.clock()
	end
end

-- ============ Carga del WAD (base64 -> buffer) ============
local dec = table.create(256, 0)
do
	local a = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
	for i = 1, 64 do dec[string.byte(a, i)] = i - 1 end
end

local wad, wadSize
do
	local chunks = script.WadChunks:GetChildren()
	table.sort(chunks, function(x, y) return x.Name < y.Name end)
	local strs, total, pads = {}, 0, 0
	for i, m in chunks do
		local s = require(m)
		strs[i] = s
		total += #s // 4 * 3
		if i == #chunks then
			if string.sub(s, -2) == "==" then pads = 2 elseif string.sub(s, -1) == "=" then pads = 1 end
		end
	end
	wad = buffer.create(total)
	local o = 0
	for _, s in strs do
		for i = 1, #s, 4 do
			local a, b, c, d = string.byte(s, i, i + 3)
			local v = bit32.bor(bit32.lshift(dec[a], 18), bit32.lshift(dec[b], 12), bit32.lshift(dec[c], 6), dec[d])
			buffer.writeu8(wad, o, bit32.rshift(v, 16))
			buffer.writeu8(wad, o + 1, bit32.band(bit32.rshift(v, 8), 255))
			buffer.writeu8(wad, o + 2, bit32.band(v, 255))
			o += 3
		end
		task.wait()
	end
	wadSize = total - pads
end
status.Text = "Inicializando Doom (puede tardar)..."

-- ============ Entrada ============
local keyQueue = {}
local KEYMAP = {
	[Enum.KeyCode.Up] = 0xad, [Enum.KeyCode.Down] = 0xaf,
	[Enum.KeyCode.Left] = 0xac, [Enum.KeyCode.Right] = 0xae,
	[Enum.KeyCode.W] = 0xad, [Enum.KeyCode.S] = 0xaf,
	[Enum.KeyCode.Q] = 0xac, [Enum.KeyCode.E] = 0xae,
	[Enum.KeyCode.A] = 44, [Enum.KeyCode.D] = 46, -- strafe , .
	[Enum.KeyCode.LeftControl] = 0x9d, [Enum.KeyCode.RightControl] = 0x9d, -- fuego
	[Enum.KeyCode.Space] = 32, -- usar
	[Enum.KeyCode.Return] = 13, [Enum.KeyCode.Escape] = 27, [Enum.KeyCode.Backspace] = 27,
	[Enum.KeyCode.Tab] = 9,
	[Enum.KeyCode.LeftShift] = 0xb6, [Enum.KeyCode.RightShift] = 0xb6, -- correr
	[Enum.KeyCode.LeftAlt] = 0xb8, [Enum.KeyCode.RightAlt] = 0xb8,
	[Enum.KeyCode.One] = 49, [Enum.KeyCode.Two] = 50, [Enum.KeyCode.Three] = 51,
	[Enum.KeyCode.Four] = 52, [Enum.KeyCode.Five] = 53, [Enum.KeyCode.Six] = 54,
	[Enum.KeyCode.Seven] = 55,
}
local function toDoomKey(input)
	if input.UserInputType == Enum.UserInputType.MouseButton1 then return 0x9d end
	local k = KEYMAP[input.KeyCode]
	if k then return k end
	local n = input.KeyCode.Name
	if #n == 1 then return string.byte(string.lower(n)) end
	return nil
end
local function push(input, pressed)
	local k = toDoomKey(input)
	if k and #keyQueue < 64 then
		table.insert(keyQueue, bit32.bor(65536, pressed and 256 or 0, k))
	end
end
UIS.InputBegan:Connect(function(i, gpe) if not gpe then push(i, true) end end)
UIS.InputEnded:Connect(function(i) push(i, false) end)

-- ============ Imports WASM ============
local mem -- se asigna tras instanciar
local function data() return mem.data end -- siempre fresco: la memoria puede crecer

local function readStr(ptr, len) return buffer.readstring(data(), ptr, len) end
local function writeU64(ptr, v)
	buffer.writeu32(data(), ptr, v % 4294967296)
	buffer.writeu32(data(), ptr + 4, v // 4294967296)
end

local FD_WAD, FD_DIR = 4, 3
local wadPos = 0
local outBuf = ""

local wasi = {
	fd_prestat_get = function(fd, buf)
		if fd == FD_DIR then
			buffer.writeu32(data(), buf, 0)       -- tag = directorio
			buffer.writeu32(data(), buf + 4, 1)   -- longitud del nombre "/"
			return 0
		end
		return 8 -- EBADF
	end,
	fd_prestat_dir_name = function(fd, ptr, len)
		buffer.writeu8(data(), ptr, 47) -- "/"
		return 0
	end,
	fd_fdstat_get = function(fd, buf)
		local d = data()
		local ft = (fd <= 2) and 2 or (fd == FD_DIR and 3 or 4)
		buffer.fill(d, buf, 0, 24)
		buffer.writeu8(d, buf, ft)
		for i = 0, 3 do buffer.writeu32(d, buf + 8 + i * 4, 0xFFFFFFFF) end -- todos los derechos
		return 0
	end,
	path_open = function(dirfd, dirflags, ptr, len, oflags, rb, ri, fdflags, outPtr)
		local p = string.lower(readStr(ptr, len)):gsub("^%./", ""):gsub("^/", "")
		if p == WAD_NAME and oflags == 0 then
			wadPos = 0
			buffer.writeu32(data(), outPtr, FD_WAD)
			return 0
		end
		return 44 -- ENOENT
	end,
	fd_read = function(fd, iovs, iovsLen, nreadPtr)
		maybeYield()
		local d = data()
		local total = 0
		if fd == FD_WAD then
			for i = 0, iovsLen - 1 do
				local bufPtr = buffer.readu32(d, iovs + i * 8)
				local bufLen = buffer.readu32(d, iovs + i * 8 + 4)
				local n = math.min(bufLen, wadSize - wadPos)
				if n > 0 then
					buffer.copy(d, bufPtr, wad, wadPos, n)
					wadPos += n
					total += n
				end
			end
		end
		buffer.writeu32(d, nreadPtr, total)
		return 0
	end,
	fd_pread = function(fd, iovs, iovsLen, off, nreadPtr)
		local d = data()
		local saved = wadPos
		wadPos = off
		local r = nil
		local total = 0
		for i = 0, iovsLen - 1 do
			local bufPtr = buffer.readu32(d, iovs + i * 8)
			local bufLen = buffer.readu32(d, iovs + i * 8 + 4)
			local n = math.max(0, math.min(bufLen, wadSize - wadPos))
			if n > 0 then buffer.copy(d, bufPtr, wad, wadPos, n); wadPos += n; total += n end
		end
		wadPos = saved
		buffer.writeu32(d, nreadPtr, total)
		return 0
	end,
	fd_seek = function(fd, offset, whence, newPtr)
		if fd ~= FD_WAD then return 70 end -- ESPIPE
		if whence == 0 then wadPos = offset
		elseif whence == 1 then wadPos += offset
		else wadPos = wadSize + offset end
		writeU64(newPtr, wadPos)
		return 0
	end,
	fd_tell = function(fd, ptr) writeU64(ptr, wadPos) return 0 end,
	fd_filestat_get = function(fd, buf)
		local d = data()
		buffer.fill(d, buf, 0, 64)
		buffer.writeu8(d, buf + 16, fd == FD_WAD and 4 or 2)
		writeU64(buf + 32, fd == FD_WAD and wadSize or 0)
		return 0
	end,
	fd_close = function() return 0 end,
	fd_sync = function() return 0 end,
	fd_write = function(fd, iovs, iovsLen, nwPtr)
		local d = data()
		local total = 0
		for i = 0, iovsLen - 1 do
			local p = buffer.readu32(d, iovs + i * 8)
			local l = buffer.readu32(d, iovs + i * 8 + 4)
			if (fd == 1 or fd == 2) and l > 0 then
				outBuf ..= buffer.readstring(d, p, l)
				total += l
			end
		end
		while true do
			local nl = string.find(outBuf, "\n", 1, true)
			if not nl then break end
			print("[doom] " .. string.sub(outBuf, 1, nl - 1))
			outBuf = string.sub(outBuf, nl + 1)
		end
		buffer.writeu32(d, nwPtr, total)
		if fd > 2 then return 8 end
		return 0
	end,
	environ_sizes_get = function(a, b) buffer.writeu32(data(), a, 0) buffer.writeu32(data(), b, 0) return 0 end,
	environ_get = function() return 0 end,
	args_sizes_get = function(a, b) buffer.writeu32(data(), a, 0) buffer.writeu32(data(), b, 0) return 0 end,
	args_get = function() return 0 end,
	clock_time_get = function(id, prec, ptr) writeU64(ptr, math.floor(os.clock() * 1e9)) return 0 end,
	random_get = function(ptr, len)
		local d = data()
		for i = 0, len - 1 do buffer.writeu8(d, ptr + i, math.random(0, 255)) end
		return 0
	end,
	sched_yield = function() return 0 end,
	proc_exit = function(code) error("Doom termino (proc_exit " .. tostring(code) .. "). Revisa la salida [doom] en consola.") end,
}
setmetatable(wasi, { __index = function(_, name)
	return function() warn("WASI sin implementar: " .. name) return 52 end -- ENOSYS
end })

local env = {
	ticks_ms = function()
		maybeYield()
		return bit32.band(math.floor(os.clock() * 1000), 0x7FFFFFFF)
	end,
	sleep_ms = function() task.wait() lastYield = os.clock() end,
	key_pop = function()
		if #keyQueue == 0 then return 0 end
		return table.remove(keyQueue, 1)
	end,
}

-- ============ ADAPTADOR de Wasynth (ajusta si tu version difiere) ============
local Module = require(script.DoomWasm)
local new = Module.new or Module.init
local instance = new({ env = env, wasi_snapshot_preview1 = wasi })
local fn = instance.func_list or instance.exports
local memories = instance.memory_list or instance.memories
mem = memories.memory or select(2, next(memories))
-- ============================================================================

-- ============ Pantalla ============
local image = AssetService:CreateEditableImage({ Size = Vector2.new(W, H) })
label.ImageContent = Content.fromObject(image)
local pixels = buffer.create(W * H * 4)
local N = W * H

local function present(fb)
	local src = mem.data
	for i = 0, N - 1 do
		local p = buffer.readu32(src, fb + i * 4) -- 0x00RRGGBB
		buffer.writeu32(pixels, i * 4, bit32.bor(
			bit32.band(bit32.rshift(p, 16), 0xFF),
			bit32.band(p, 0xFF00),
			bit32.lshift(bit32.band(p, 0xFF), 16),
			0xFF000000))
	end
	image:WritePixelsBuffer(Vector2.zero, Vector2.new(W, H), pixels)
end

-- ============ Bucle principal (en un hilo: los imports ceden el control) ============
task.spawn(function()
	if fn._initialize then fn._initialize() end
	fn.rb_init()
	status.Text = ""
	local fb = fn.rb_fb()
	local frames, t0 = 0, os.clock()
	while true do
		fn.rb_tick()
		present(fb)
		frames += 1
		if os.clock() - t0 >= 1 then
			status.Text = string.format("%d FPS", frames)
			frames, t0 = 0, os.clock()
		end
		RunService.Heartbeat:Wait()
		lastYield = os.clock()
	end
end)
