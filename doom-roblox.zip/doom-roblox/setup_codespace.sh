#!/usr/bin/env bash
# Ejecutar dentro de la carpeta doom-roblox, en la terminal de Codespaces
set -e
HERE="$(pwd)"

echo "== 1/4 Rust =="
if ! command -v cargo >/dev/null; then
  curl https://sh.rustup.rs -sSf | sh -s -- -y
  . "$HOME/.cargo/env"
fi

echo "== 2/4 wasi-sdk =="
if [ ! -d "$HOME/wasi-sdk" ]; then
  cd "$HOME"
  curl -L -o wasi.tar.gz https://github.com/WebAssembly/wasi-sdk/releases/download/wasi-sdk-25/wasi-sdk-25.0-x86_64-linux.tar.gz
  tar xf wasi.tar.gz
  mv wasi-sdk-25.0-x86_64-linux wasi-sdk
fi

echo "== 3/4 Compilar Doom a WASM =="
cd "$HERE"
[ -d doomgeneric ] || git clone https://github.com/ozkl/doomgeneric
WASI_SDK="$HOME/wasi-sdk" ./build_doom.sh

echo "== 4/4 Wasynth =="
cd "$HOME"
[ -d Wasynth ] || git clone https://github.com/Rerumu/Wasynth
cd Wasynth && cargo build --release
echo
echo "=== LISTO. Binarios de Wasynth: ==="
ls "$HOME/Wasynth/target/release" | grep -v '\.d$' | head -30
echo
echo "Pega en el chat la lista de arriba. doom.wasm esta en $HERE"
