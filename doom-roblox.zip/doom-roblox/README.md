# Doom en Roblox (WASM -> Luau)

1. `git clone https://github.com/ozkl/doomgeneric`
2. Instala wasi-sdk y ejecuta: `WASI_SDK=/ruta/wasi-sdk ./build_doom.sh`  -> doom.wasm
3. Compila Wasynth (`cargo build --release`), traduce doom.wasm a Luau y guarda la salida como `src/client/DoomWasm.lua`
4. Consigue doom1.wad (shareware legal) y ejecuta: `python split_wad.py doom1.wad`
5. Instala Rojo, `rojo serve` y conecta desde Studio (o `rojo build -o Doom.rbxlx`)
6. Activa en la experiencia el uso de EditableImage (requiere verificacion de cuenta) y dale a Play.

Controles: flechas o WASD/QE, Ctrl o clic = disparar, Espacio = usar, Shift = correr, 1-7 armas, Backspace = Esc (menu).
